n1 = int(input("Informe o numero:"))
i = 1
temp = 1

while i <= n1:
    temp = temp * i
    i+=1

print(temp)
